1:"$Sreact.fragment"
2:I[7796,["177","static/chunks/app/layout-4cc72219363cb9c4.js"],"ThemeProvider"]
3:I[87,[],""]
4:I[123,[],""]
5:I[8511,["177","static/chunks/app/layout-4cc72219363cb9c4.js"],"Analytics"]
6:I[6242,[],"ClientPageRoot"]
7:I[9826,["550","static/chunks/ed48eaa7-14ed6c3f91f3473e.js","511","static/chunks/511-14fab1b4ea934c1f.js","974","static/chunks/app/page-278a47b75674a8c6.js"],"default"]
a:I[5093,[],"OutletBoundary"]
d:I[5093,[],"ViewportBoundary"]
f:I[5093,[],"MetadataBoundary"]
11:I[4786,[],""]
:HL["/_next/static/css/c9da7dc9b728c8ca.css","style"]
:HL["/_next/static/css/3ea2f29e3314018f.css","style"]
0:{"P":null,"b":"Kxk0DmQQaOT8s6v10onBr","p":"","c":["",""],"i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/c9da7dc9b728c8ca.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/css/3ea2f29e3314018f.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","suppressHydrationWarning":true,"children":["$","body",null,{"className":"font-sans antialiased","children":[["$","$L2",null,{"attribute":"class","defaultTheme":"system","enableSystem":true,"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","$L5",null,{}]]}]}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L6",null,{"Component":"$7","searchParams":{},"params":{},"promises":["$@8","$@9"]}],"$undefined",null,["$","$La",null,{"children":["$Lb","$Lc",null]}]]}],{},null,false]},null,false],["$","$1","h",{"children":[null,["$","$1","DP4FGCR2-pODZq7Cf3cRF",{"children":[["$","$Ld",null,{"children":"$Le"}],null]}],["$","$Lf",null,{"children":"$L10"}]]}],false]],"m":"$undefined","G":["$11","$undefined"],"s":false,"S":true}
8:{}
9:{}
e:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
b:null
c:null
10:[["$","title","0",{"children":"Sistema de Alertas"}],["$","meta","1",{"name":"description","content":"Sistema de Monitoramento e Alertas para Clientes"}],["$","meta","2",{"name":"generator","content":"v0.app"}],["$","link","3",{"rel":"icon","href":"/icon.svg?f32e15facd4a8dcd","type":"image/svg+xml","sizes":"any"}]]
